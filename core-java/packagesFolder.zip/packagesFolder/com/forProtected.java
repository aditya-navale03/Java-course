package com;

public class forProtected {
    protected void data2() {
        System.out.println("this is class for protected");
    }
}
