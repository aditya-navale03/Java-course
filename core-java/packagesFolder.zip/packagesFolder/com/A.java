package com;

public class A {
    public void show() {
        System.out.println("This is show() from class A in package com");
    }
}
