package com;

public class forPrivate {
    private void data1() {
        System.out.println("this is for private data");
    }
}
